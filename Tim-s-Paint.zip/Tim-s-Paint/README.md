# Tim's Paint
Android Paint Project created using Android Java. [This app is available in the Android Store for free](https://play.google.com/store/apps/details?id=fundraw.com.timspaint&hl=en).

## IDE and Language 
The IDE used while making this is Android Studio.

The Language that this project uses is Android Java.

## Where the Main Logic is at
The File path to where most of my programming work is [Tim-s-Paint/app/src/main/java/fundraw/com/timspaint/](https://github.com/timothy/Tim-s-Paint/tree/master/app/src/main/java/fundraw/com/timspaint)

## Usage

This was created with an older version of Android Studio there may need to be changes in order to compile with the latest version of Android Studio.

## Contributing

1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request :D
